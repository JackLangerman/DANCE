The paper link: https://drive.google.com/file/d/1peficAF0Qjye9ek2GNovZGWLf3P5ZCDI/view?usp=sharing

The data set link: https://drive.google.com/drive/folders/133-jrf-YzNtuMve482oFRtSXzhX77Hqf?usp=sharing.
Inside the link, we have train folders with 100,000 labeled rendered images and	28411 unlabeled	real camera images.
We also	have the validation set	(1637 labeled real camera images) and test set (2104 labeled real camera images).

Training:
(1) histogram_match.ipynb to preprocess the training rendered images.

(2) going into cut folder, use the prepare_dataset.ipynb to prepare training data, run run_py_job.sbatch to train the cut based gan model.

(3) train_init_scr_cut.ipynb to train the final SCR model.

Testing:
(1) test.ipynb
